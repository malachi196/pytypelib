# pytypelib 
Some more helpful python types and objects